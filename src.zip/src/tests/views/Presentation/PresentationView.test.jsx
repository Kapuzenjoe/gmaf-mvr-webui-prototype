import React from 'react';
import { render, screen } from '@testing-library/react';
import PresentationView from '../../../views/Presentation/PresentationView';
import CMMCOunzipService from '../../../service/CMMCOunzipService';

jest.mock('../../../service/CMMCOunzipService');
jest.mock('../../../components/PlayerWrapper', () => (props) => (
  <div data-testid="player-wrapper">{props.children}</div>
));

describe('PresentationView ZIP handling', () => {
  test('renders PlayerWrappers from ZIP content', async () => {
    const fakeItem = {
      mimeType: 'application/zip',
      fileUrl: 'http://example.com/fake.zip',
      generalMetadata: { id: 'abc', fileName: 'bundle.zip' },
    };

    CMMCOunzipService.extractMediaItemsFromCMMCO.mockResolvedValue([
      {
        fileName: 'video.mp4',
        mimeType: 'video/mp4',
        blobUrl: 'blob:http://localhost/video',
      },
      {
        fileName: 'pulse.csv',
        mimeType: 'text/csv',
        blobUrl: 'blob:http://localhost/pulse',
      },
    ]);

    render(<PresentationView item={fakeItem} />); // 👈 wichtig: item, nicht currentItem

    const players = await screen.findAllByTestId('player-wrapper');
    expect(players.length).toBe(2);
  });
});
